import numpy as np
import tensorflow as tf
import random
import os
os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1' # 设置环境，激活混合精度功能，提升训练速度
n_train = 400  # 设置训练集样本个数
batch_size = 16  # 设置每次训练使用的样本个数
train_step = 30000  # 设置总训练次数
step_display = 1000  # 设置每训练多少次打印一次训练结果
learning_reat_base = 0.01  # 基准学习率
learning_reat_step = 100  # 设置每训练多少次调整一次学习率
learning_reat_decay = 0.97  # 设置学习率每次调整的幅度
n1 = 16  # 第1个隐藏层的神经元个数
n2 = 32  # 第2个隐藏层的神经元个数
n3 = 16  # 第3个隐藏层的神经元个数
kp = 1.0  # keep prob功能，用于防止过拟合，若设置为1.0则关闭该功能
l2_reat = 0.0008  # l2正则化参数，l2正则化用于防止过拟合
file_data = 'data.csv'  # 数据文件路径
file_output_tr = 'output_train.csv'  # 输出训练集数据的预测值的文件路径
file_output_te = 'output_text.csv'  # 输出测试集数据的预测值的文件路径
file_save = 'model_DNN.ckpt'  # 保存神经网络模型的文件路径

data = np.genfromtxt(file_data, dtype=float, delimiter=',')  # 读取数据
max_list = np.max(data[0:n_train], axis=0)  # 计算数据的最大值
min_list = np.min(data[0:n_train], axis=0)  # 计算数据的最小值
data = (data-min_list)/(max_list-min_list)  # 对数据进行标准化

row, col = data.shape
n_text = row-n_train  # 测试集样本数量

input_train = data[0: n_train, 0:6]  # 训练集输入数据
input_text = data[n_train: row, 0:6]  # 测试集输入数据
output_train = data[0: n_train, 6:7]  # 训练集输出数据
output_text = data[n_train: row, 6:7]  # 测试集输出数据

input1 = tf.placeholder(tf.float32)
output = tf.placeholder(tf.float32)

n_input = int(input_train.shape[1])
n_output = int(output_train.shape[1])

print('n_input = ' + str(n_input))
print('n_output = ' + str(n_output))

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

keep_prob = tf.placeholder(tf.float32)

W_fc1 = weight_variable([n_input, n1])
b_fc1 = bias_variable([n1])

h_fc1 = tf.nn.relu(tf.matmul(input1, W_fc1) + b_fc1)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([n1, n2])
b_fc2 = bias_variable([n2])

h_fc2 = tf.nn.relu(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)
h_fc2_drop = tf.nn.dropout(h_fc2, keep_prob)

W_fc3 = weight_variable([n2, n3])
b_fc3 = bias_variable([n3])

h_fc3 = tf.nn.relu(tf.matmul(h_fc2_drop, W_fc3) + b_fc3)
h_fc3_drop = tf.nn.dropout(h_fc3, keep_prob)

W_fc4 = weight_variable([n3, n_output])
b_fc4 = bias_variable([n_output])
output_predict = tf.matmul(h_fc3_drop, W_fc4) + b_fc4

loss = tf.reduce_mean(tf.abs(output_predict - output))  # 设置损失函数

# l2正则化
loss_l2 = tf.contrib.layers.l2_regularizer(l2_reat)(W_fc1) + \
          tf.contrib.layers.l2_regularizer(l2_reat)(W_fc2)\
          + tf.contrib.layers.l2_regularizer(l2_reat)(W_fc3) + \
          tf.contrib.layers.l2_regularizer(l2_reat)(W_fc4)

# 指数衰减学习率
global_steps = tf.Variable(0, trainable=False)
learning_rate = tf.train.exponential_decay(
    learning_reat_base,
    global_steps,
    learning_reat_step,
    learning_reat_decay,
    staircase=True)

train_op = tf.train.AdamOptimizer(learning_rate).minimize(loss+loss_l2, global_step=global_steps)

saver = tf.train.Saver()

tf_config = tf.ConfigProto()
tf_config.gpu_options.allow_growth = True  # 自适应GPU内存，防止GPU内存占用过高

with tf.Session(config=tf_config) as sess:
    init_op = tf.global_variables_initializer()
    sess.run(init_op)

    for step in range(train_step):
        index = random.sample(range(0, n_train), batch_size)
        sess.run(train_op, feed_dict={input1: input_train[index],
                                      output: output_train[index],
                                      keep_prob: kp})

        if step % step_display == 0:
            loss_tr = sess.run(loss, feed_dict={input1: input_train,
                                                output: output_train,
                                                keep_prob: 1.0})
            loss_te = sess.run(loss, feed_dict={input1: input_text,
                                                output: output_text,
                                                keep_prob: 1.0})
            print('step: ' + str(step))
            print('loss_tr: ' + str(loss_tr) +
                  '  loss_te: ' + str(loss_te) +
                  '  loss_l2: ' + str(sess.run(loss_l2)))
    loss_tr = sess.run(loss, feed_dict={input1: input_train, output: output_train, keep_prob: 1.0})
    loss_te = sess.run(loss, feed_dict={input1: input_text, output: output_text, keep_prob: 1.0})
    print('step: ' + str(step))
    print('loss_tr: ' + str(loss_tr) + '  loss_te: ' + str(loss_te))
    output_train_2 = sess.run(output_predict, feed_dict={
        input1: input_train, keep_prob: 1.0})
    output_train_2 = output_train_2 * (max_list[6:7] - min_list[6:7]) + min_list[6:7]
    output_text_2 = sess.run(output_predict, feed_dict={
        input1: input_text, keep_prob: 1.0})
    output_text_2 = output_text_2 * (max_list[6:7] - min_list[6:7]) + min_list[6:7]
    np.savetxt(file_output_tr, output_train_2)
    np.savetxt(file_output_te, output_text_2)
    np.savetxt('max_list.csv', max_list)
    np.savetxt('min_list.csv', min_list)
    saver.save(sess, file_save)