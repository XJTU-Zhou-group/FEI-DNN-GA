function Y=GA_OP(x)
global k
global Data
pd=x(5)/x(6);
mdp=0.026/(1.29*x(6)^2);
mm=log10(mdp);
U_input=py.re_Ur_DNN_1.fluidelastic_U(x(1),x(2),x(3),x(4),pd,mm);
Y=-U_input;
Data(1:5,k)=[U_input;x(1);x(2);x(3);x(4)];
k=k+1;
end