import os
# os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1'
# os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import numpy as np
import tensorflow as tf
os.environ['TF_ENABLE_AUTO_MIXED_PRECISION'] = '1' # 设置环境，激活混合精度功能，提升训练速度
n1 = 16  # 第1个隐藏层的神经元个数
n2 = 32  # 第2个隐藏层的神经元个数
n3 = 16  # 第3个隐藏层的神经元个数
file_data_input = 'data_m_input.csv'  # 数据文件路径
file_data_output = 'data_m_output.csv'  # 数据文件路径
file_save = 'model_DNN.ckpt'  # 保存神经网络模型的文件路径

data_input = np.genfromtxt(file_data_input, dtype=float, delimiter=',')  # 读取数据
min_list = np.genfromtxt('min_list.csv', dtype=float, delimiter=',')  # 计算数据的均值
max_list = np.genfromtxt('max_list.csv', dtype=float, delimiter=',')  # 计算数据的标准差
data_input = (data_input - min_list[0:6])/(max_list[0:6] - min_list[0:6])

input1 = tf.placeholder(tf.float32)

n_input = 6
n_output = 1

print('n_input = ' + str(n_input))
print('n_output = ' + str(n_output))

def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

keep_prob = tf.placeholder(tf.float32)

W_fc1 = weight_variable([n_input, n1])
b_fc1 = bias_variable([n1])

h_fc1 = tf.nn.relu(tf.matmul(input1, W_fc1) + b_fc1)
h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

W_fc2 = weight_variable([n1, n2])
b_fc2 = bias_variable([n2])

h_fc2 = tf.nn.relu(tf.matmul(h_fc1_drop, W_fc2) + b_fc2)
h_fc2_drop = tf.nn.dropout(h_fc2, keep_prob)

W_fc3 = weight_variable([n2, n3])
b_fc3 = bias_variable([n3])

h_fc3 = tf.nn.relu(tf.matmul(h_fc2_drop, W_fc3) + b_fc3)
h_fc3_drop = tf.nn.dropout(h_fc3, keep_prob)

W_fc4 = weight_variable([n3, n_output])
b_fc4 = bias_variable([n_output])
output_predict = tf.matmul(h_fc3_drop, W_fc4) + b_fc4

saver = tf.compat.v1.train.Saver()

tf_config = tf.compat.v1.ConfigProto()
tf_config.gpu_options.allow_growth = True # 自适应

with tf.compat.v1.Session(config=tf_config) as sess:
    saver.restore(sess, file_save)
    data_output = sess.run(output_predict, feed_dict={input1: data_input, keep_prob: 1.0}) * \
                  (max_list[6:7] - min_list[6:7]) + min_list[6:7]
    sess.close()

print(data_output)
#np.savetxt(file_data_output, data_output)
